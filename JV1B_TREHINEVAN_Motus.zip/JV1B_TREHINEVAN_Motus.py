from colorama import Back, Fore, Style, deinit, init

with open("mots6.txt", "r") as file:
    allText = file.read()
    mot = list(map(str, allText.split()))

longueurmot = len(mot)


proposition = input("entrez un mot en 6 lettres : ")
if proposition == mot:
    print (Fore.BLUE + Style.NORMAL + 'bravo')

longueur = len(proposition)

lettre1 = proposition[longueur-6]
lettre2 = proposition[longueur-5]
lettre3 = proposition[longueur-4]
lettre4 = proposition[longueur-3]
lettre5 = proposition[longueur-2]
lettre6 = proposition[longueur-1]

if lettre1 == mot[longueurmot-6]:
    print (Fore.BLUE + Style.NORMAL + (lettre1))
elif lettre1 == mot[longueurmot-5]:
    print (Fore.YELLOW + Style.NORMAL + (lettre1))
elif lettre1 == mot[longueurmot-4]:
    print (Fore.YELLOW + Style.NORMAL + (lettre1))
elif lettre1 == mot[longueurmot-3]:
    print (Fore.YELLOW + Style.NORMAL + (lettre1))
elif lettre1 == mot[longueurmot-2]:
    print (Fore.YELLOW + Style.NORMAL + (lettre1))
elif lettre1 == mot[longueurmot-1]:
    print (Fore.YELLOW + Style.NORMAL + (lettre1))
else:
    print (Fore.RED + Style.NORMAL + (lettre1))